#IMPORTING THE GAME MODULES
import pygame, sys
import sheet_extract as crop

#class and functions for game


#the main game func
class Game:

	def __init__(self):
		self.state = "games"  #the state of game

	def main_game(self):  #the main game
		global left,right,up,down
		for event in pygame.event.get():
			if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN
			                                 and event.key == pygame.K_ESCAPE):
				pygame.quit()
				sys.exit()
			if event.type == pygame.KEYDOWN:
						if event.key == pygame.K_LEFT:
							left = True
						if event.key == pygame.K_RIGHT:
							right = True
						if event.key == pygame.K_UP:
							up = True
						if event.key == pygame.K_DOWN:
							down = True

				#screen bg
		screen.fill(white)
		road.update()
		screen.blit(bg_road, (0, 0))
		road.create_road("road.png")
		players.update()
		players.draw(screen)
		pygame.display.flip()


#class for the road
class Road:

	def __init__(self):
		#roads size setup
		self.road_width = 700
		self.road_height = 1500
		self.road_size = (self.road_width, self.road_height)
		#setup the position and velocity of the road
		self.pos_x = 50
		self.pos_y = -250
		self.velocity = 6

	def create_road(self, img):  #creating road
		self.road = pygame.Surface(self.road_size).convert_alpha()
		self.image = pygame.transform.smoothscale(pygame.image.load(img).convert_alpha(),self.road_size)
		self.road.blit(self.image, (0, 0))
		self.road.set_colorkey(black)
		screen.blit(self.road, (self.pos_x, self.pos_y))

	def update(self):
		self.pos_y += self.velocity
		if self.pos_y >= 0:
			self.pos_y = -340


#player's class
class Player(pygame.sprite.Sprite):

	def __init__(self, image):
		super().__init__()
		self.pos_x = 0
		self.pos_y = (screen_height-61)*4//5
		self.velocity = 5
		self.image = image.convert_alpha()
		self.rect = self.image.get_rect()
		self.rect.topleft = (self.pos_x * 250+91, self.pos_y)
	def update(self):
		global left,right,up,down
		if left == True and self.pos_x>0:
			self.pos_x -= 1
			left = False
			print("left",self.pos_x)
		if right == True and self.pos_x<2:
			self.pos_x += 1
			right = False
			print("right",self.pos_x)
		if up == True and self.pos_y>=0:
			self.pos_y -= self.velocity
			up = False
			print("up",self.pos_y)
		if down == True and self.pos_y <= 1000:
			self.pos_y += self.velocity
			down = False
			print("down",self.pos_y)
		self.rect.topleft = (self.pos_x * 250+91, self.pos_y)
			


#staring the game
pygame.init()
clock = pygame.time.Clock()

#game var setup
fps = 60. #fps of the game
screen_width = 800
screen_height = 1000
rolled_player = 2
left = False
right = False
down = False
up = False

#loading the img for game
bg_road = pygame.transform.scale(pygame.image.load("side.png"), (800, 1500))
player_cars = [
 crop.sheet_selector("car.png", 61, 111, i,1,2) for i in range(1, 4)
]

#setup player car
player = Player(player_cars[rolled_player])
players = pygame.sprite.Group()
players.add(player)

#set up road
road = Road()

#colors
white = (255, 255, 255)
black = (0, 0, 0)

#define the game screen
screen = pygame.display.set_mode((screen_width, screen_height))

#define the game
game = Game()
#game loop
while True:
	game.main_game()
	clock.tick(fps)
