#IMPORTING THE GAME MODULES
import pygame, sys
import sheet_extract as crop

#class and functions for game


#the main game func
class Game:

	def __init__(self):
		self.state = "games"  #the state of game

	def main_game(self):  #the main game
		global player_side_shift, pos_y
		for event in pygame.event.get():
			if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN
			                                 and event.key == pygame.K_ESCAPE):
				pygame.quit()
				sys.exit()
			if event.type == pygame.KEYDOWN:
				if (player_side_shift > 0 and player_side_shift <= 3):
					if event.key == pygame.K_LEFT:
						player_side_shift -= 1
					if event.key == pygame.K_RIGHT:
						player_side_shift += 1
				if event.key == pygame.K_UP:
					pos_y += 1
				if event.key == pygame.K_DOWN:
					pos_y -= 1

				#screen bg
		screen.fill(white)
		road.update()
		screen.blit(bg_road, (0, 0))
		road.create_road("road.png")
		players.draw(screen)
		pygame.display.flip()


#class for the road
class Road:

	def __init__(self):
		#roads size setup
		self.road_width = 700
		self.road_height = 1000
		self.road_size = (self.road_width, self.road_height)
		#setup the position and velocity of the road
		self.pos_x = 50
		self.pos_y = -250
		self.vel = 3

	def create_road(self, img):  #creating road
		self.road = pygame.Surface(self.road_size)
		self.image = pygame.image.load(img)
		self.road.blit(self.image, (0, 0))
		self.road.set_colorkey(black)
		screen.blit(self.road, (self.pos_x, self.pos_y))

	def update(self):
		self.pos_y += self.vel
		if self.pos_y >= 0:
			self.pos_y = -240


#player's class
class Player(pygame.sprite.Sprite):

	def __init__(self, image, left_move, pos_y):
		super().__init__()
		self.image = image
		self.rect = self.image.get_rect()
		self.rect.topleft = (left_move * 91, pos_y)


#staring the game
pygame.init()
clock = pygame.time.Clock()

#game var setup
fps = 30  #fps of the game
screen_width = 800
screen_height = 1000
player_side_shift = 1
pos_y = (screen_height) * 1// 2
rolled_player = 2

#loading the img for game
bg_road = pygame.transform.scale(pygame.image.load("side.png"), (800, 1500))
player_cars = [
 crop.sheet_selector("car.png", 61, 111, i,1,2) for i in range(1, 4)
]

#setup player car
player = Player(player_cars[rolled_player], player_side_shift, pos_y)
players = pygame.sprite.Group()
players.add(player)

#set up road
road = Road()

#colors
white = (255, 255, 255)
black = (0, 0, 0)

#define the game screen
screen = pygame.display.set_mode((screen_width, screen_height))

#define the game
game = Game()
#game loop
while True:
	game.main_game()
	clock.tick(fps)