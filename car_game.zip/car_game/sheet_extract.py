import pygame

pygame.init()

screen = pygame.display.set_mode((800,800))

def sheet_selector(img_, width, height, row, column, scale):
	img = pygame.image.load(img_)
	image = pygame.Surface((width, height))
	image.blit(img, (0, 0), (width * (row - 1), height *
	                         (column - 1), width * row, height * column))
	image = pygame.transform.scale(image, (width * scale, height * scale))
	image.set_colorkey((0, 0, 0))
	return image
